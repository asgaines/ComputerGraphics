hw2: Projections

Andrew Gaines
CSCI4229/5229 Summer 2016

Draw cave with randomly generated stalagtites and stalagmites and a mysterious chest.
Some intuition and code borrowed from [lighthouse3D](http://www.lighthouse3d.com/tutorials/glut-tutorial/keyboard-example-moving-around-the-world/)

Key bindings
  m          Toggle modes between orthogonal (0), perspective (1), first-person navigation (2)
  +/-        Changes field of view for perspective
  w          Move forward (only in mode 2)
  a          Turn left
  s          Move backwards (only in mode 2)
  d          Turn right
  l/r arrows     Change view angle
  PgDn/PgUp  Zoom in and out
  0          Reset view angle
  ESC        Exit

Approximate time: 12hr
